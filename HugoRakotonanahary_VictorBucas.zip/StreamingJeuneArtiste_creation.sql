Use streamingjeuneartiste;


-- Table artiste : le nom, prenom et la date de naissance de tous les artistes, aucun champ ne peut etre nul (on a forcément un nom, un prémon et une date de naissance)
CREATE TABLE Artiste(
   ID_Artiste INT,
   Nom_Artiste VARCHAR(50) NOT NULL,
   Prenom_Artiste VARCHAR(50) NOT NULL,
   DateNaissance_Artiste DATE NOT NULL,
   PRIMARY KEY(ID_Artiste)
);

-- Table Oeuvre : contient différentes caractéristiques d'une oeuvre
CREATE TABLE Oeuvre(
   ID_Oeuvre INT,
   Nom_Oeuvre VARCHAR(50) NOT NULL,
   Durée_Oeuvre TIME NOT NULL,
   Date_Oeuvre DATE NOT NULL,
   Type_Oeuvre VARCHAR(50) NOT NULL,
   PRIMARY KEY(ID_Oeuvre)
);


CREATE TABLE Plateforme_Streaming(
   Nom_Streaming VARCHAR(50),
   NbUtilisateur_Streaming INT NOT NULL,
   PRIMARY KEY(Nom_Streaming)
);

CREATE TABLE Genre_Oeuvre(
   Nom_Genre VARCHAR(50),
   PRIMARY KEY(Nom_Genre)
);

CREATE TABLE Profession_Artiste(
   Nom_Profession VARCHAR(50),
   PRIMARY KEY(Nom_Profession)
);

CREATE TABLE Utilisateur(
   ID_Utilisateur INT,
   Nom_Utilisateur VARCHAR(50) NOT NULL,
   Prenom_Utilisateur VARCHAR(50) NOT NULL,
   PRIMARY KEY(ID_Utilisateur)
);


-- table lien entre profession_artiste et artiste pour savoir de quel profession est un artiste
CREATE TABLE Être(
   ID_Artiste INT,
   Nom_Profession VARCHAR(50),
   PRIMARY KEY(ID_Artiste, Nom_Profession),
   FOREIGN KEY(ID_Artiste) REFERENCES Artiste(ID_Artiste),
   FOREIGN KEY(Nom_Profession) REFERENCES Profession_Artiste(Nom_Profession)
);
-- table lien entre oeuvre et artiste pour savoir qui a participé à la création de l'oeuvre
CREATE TABLE Participer(
   ID_Artiste INT,
   ID_Oeuvre INT,
   PRIMARY KEY(ID_Artiste, ID_Oeuvre),
   FOREIGN KEY(ID_Artiste) REFERENCES Artiste(ID_Artiste),
   FOREIGN KEY(ID_Oeuvre) REFERENCES Oeuvre(ID_Oeuvre)
);

-- table lien entre Plateforme_Streaming et Genre_Oeuvre pour savoir quels genres de films sont sur une plateforme de streaming
CREATE TABLE Contient(
   Nom_Streaming VARCHAR(50),
   Nom_Genre VARCHAR(50),
   PRIMARY KEY(Nom_Streaming, Nom_Genre),
   FOREIGN KEY(Nom_Streaming) REFERENCES Plateforme_Streaming(Nom_Streaming),
   FOREIGN KEY(Nom_Genre) REFERENCES Genre_Oeuvre(Nom_Genre)
);

-- table lien entre Oeuvre et Genre_Oeuvre pour savoir quels sont les genres 
CREATE TABLE Attribuer(
   ID_Oeuvre INT,
   Nom_Genre VARCHAR(50),
   PRIMARY KEY(ID_Oeuvre, Nom_Genre),
   FOREIGN KEY(ID_Oeuvre) REFERENCES Oeuvre(ID_Oeuvre),
   FOREIGN KEY(Nom_Genre) REFERENCES Genre_Oeuvre(Nom_Genre)
);

-- table lien entre Oeuvre et Plateforme_Streaming pour savoir quelles oeuvres sont sur quelles plateformes de streaming
CREATE TABLE Contenir(
   ID_Oeuvre INT,
   Nom_Streaming VARCHAR(50),
   PRIMARY KEY(ID_Oeuvre, Nom_Streaming),
   FOREIGN KEY(ID_Oeuvre) REFERENCES Oeuvre(ID_Oeuvre),
   FOREIGN KEY(Nom_Streaming) REFERENCES v(Nom_Streaming)
);

-- table lien entre Plateforme_Streaming et Utilisateur pour savoir quel utilisateur est abonné à quelle plateforme
CREATE TABLE Abonner(
   Nom_Streaming VARCHAR(50),
   ID_Utilisateur INT,
   PRIMARY KEY(Nom_Streaming, ID_Utilisateur),
   FOREIGN KEY(Nom_Streaming) REFERENCES Plateforme_Streaming(Nom_Streaming),
   FOREIGN KEY(ID_Utilisateur) REFERENCES Utilisateur(ID_Utilisateur)
);
