describe artiste;
describe profession_artiste;
describe oeuvre;
describe genre_oeuvre;
describe plateforme_streaming;

-- Le principe de cette base est de faire la promtion de jeunes artistes donc l'age maximum pour pouvoir etre entré dans la table est de 30 ans
alter table artiste
add constraint DateNaissance_Artiste check (DateNaissance_Artiste > '1994-01-01' And DateNaissance_Artiste < '2024-01-01');

-- On limite les possibilités de metiers dans la table
alter table profession_artiste
add constraint Nom_Profession check (Nom_Profession LIKE 'Realisateur' OR Nom_Profession LIKE 'Acteur' OR Nom_Profession LIKE 'Compositeur' OR Nom_Profession LIKE 'Doubleur' 
OR Nom_Profession LIKE 'Cascadeur' OR Nom_Profession LIKE 'Directeur Artistique' OR Nom_Profession LIKE 'Comédien' OR Nom_Profession LIKE 'Chanteur' 
OR Nom_Profession LIKE 'Producteur' OR Nom_Profession LIKE 'Mannequin' OR Nom_Profession LIKE 'Danseur' OR Nom_Profession LIKE 'Rappeur' OR Nom_Profession LIKE 'Musicien');

-- On limite le nom des différents types d'oeuvres, on cherche à promouvoir des films récents donc on limite l'age des films à 5 ans
alter table Oeuvre
add constraint Type_Oeuvre check (Type_Oeuvre LIKE ('serie','film','one man show','représentation théatrale')),
add constraint Date_Oeuvre check (Date_Oeuvre > '2019-01-01');

-- On limite les genres de film
alter table genre_oeuvre
add constraint Nom_Genre check (Nom_Genre LIKE 'Horreur' OR Nom_Genre LIKE 'Drame' OR Nom_Genre LIKE 'Action' OR Nom_Genre LIKE 'Science-Fiction' 
OR Nom_Genre LIKE 'Thriller' OR Nom_Genre LIKE 'Comédie' OR Nom_Genre LIKE 'Fantaisie' OR Nom_Genre LIKE 'Western' OR Nom_Genre LIKE 'Aventure' 
OR Nom_Genre LIKE 'Documentaire' OR Nom_Genre LIKE 'Romance' OR Nom_Genre LIKE 'Dessin anime' OR Nom_Genre LIKE 'comedie musicale');

-- une plateforme de streaming ne peut pas avoir un nombre négatif d'utilisateurs
alter table plateforme_streaming
add constraint NbUtilisateur_Streaming check (NbUtilisateur_Streaming >= 0);

