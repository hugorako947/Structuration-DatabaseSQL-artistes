use streamingjeuneartiste;
-- n'hésitez pas à modifier les variables

-- En donnant le nom d'un film en parametre on peut obtenir les artiste ayants travaillé dessus
set @Film = 'Dune partie 1';
select distinct a.Nom_Artiste, a.Prenom_Artiste, o.Nom_Oeuvre from artiste a, oeuvre o 
join participer p on ID_Artiste = p.ID_Artiste and p.ID_Oeuvre = o.ID_Oeuvre 
where o.Nom_Oeuvre = @Film order by a.Nom_Artiste;


-- En donnant le nom d'un genre, on obtient la liste de tous les films de ce genre
set @Genre = 'Horreur';
select distinct o.Nom_Oeuvre, o.Durée_Oeuvre, o.Date_Oeuvre, o.Type_Oeuvre from oeuvre o 
join attribuer a on o.ID_Oeuvre = a.ID_Oeuvre 
join genre_oeuvre g on a.Nom_Genre = g.Nom_Genre 
where g.Nom_Genre = @Genre;


-- En donnant le nom d'un artiste on obtient les genres de films sur lesquels il a participé
set @N_artiste = 'Chalamet', @P_Artiste = 'Timothée';
select distinct a.Nom_Artiste, a.Prenom_Artiste, g.Nom_Genre from artiste a, Genre_Oeuvre g
join participer pa on ID_Artiste = pa.ID_artiste 
join Oeuvre o on pa.ID_Oeuvre = o.ID_Oeuvre 
join attribuer att on o.ID_Oeuvre = att.ID_Oeuvre 
join Genre_Oeuvre go on att.Nom_Genre = go.Nom_Genre 
where a.Nom_Artiste = @N_Artiste and a.Prenom_Artiste = @P_Artiste;


-- En donnant un utilisateur un genre et un type de film, on obtient tous les films auquel l'utilisateur a accès en respectant le genre et le type
set @ID_User = 2, @Genre = 'Action', @Type_Oeuvre = 'film'; 
select distinct o.Nom_Oeuvre, o.Date_Oeuvre from Oeuvre o, Genre_Oeuvre g 
join attribuer a on ID_Oeuvre = a.ID_Oeuvre and a.Nom_Genre = g.Nom_Genre 
join contenir c on c.ID_Oeuvre = a.ID_Oeuvre
join Plateforme_Streaming s on c.Nom_Streaming = s.Nom_Streaming 
join abonner ab on ab.Nom_Streaming = ab.Nom_Streaming 
join utilisateur u on ab.ID_Utilisateur = u.ID_Utilisateur and u.ID_utilisateur = @ID_User 
where g.Nom_Genre = @Genre and o.Type_Oeuvre = @Type_Oeuvre;


-- En donnant un utilisateur, on obtient une liste de tous les genres auquel il a accès à travers ses abonnements aux plateformes de streaming
set @ID_User = 5;
select distinct g.Nom_Genre from genre_Oeuvre g 
join contient c on g.Nom_Genre = c.Nom_Genre 
join Plateforme_Streaming s on s.Nom_streaming = c.Nom_streaming 
join abonner a on s.Nom_streaming = a.Nom_streaming 
join utilisateur u on u.ID_Utilisateur = a.ID_Utilisateur and u.ID_Utilisateur = @ID_User;


